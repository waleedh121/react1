

export default function About () {
    return(
        <>
        <h1 className="text-center ">About page</h1>
        </>
    )
}